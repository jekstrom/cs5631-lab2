This folder contains a Makefile that can be used to compile
the muscle server under Win32 using Borland's free C++Builder5.5
compiler.  Some warnings will be generated; ignore them.

To compile:

- Make sure you have C++Builder5.5 installed and set up (you
  can download it from Borland's web site, www.borland.com)

- Open an MS-DOS shell and cd to this folder

- type make

