In this directory you will find Dev-C++ 5 beta (4.9.50) project files,
as contributed by Marcin "Shard" Konicki.  

(based on VC++ files made by Vitaliy Mikitchenko (aka "VitViper"))

To compile muscle, do the following:

1. Open the "libmuscle.dev" project file in dev-c++

2. Now press "Compile" button to build the library. 

3. This will create a "libmuscle.a" static library in the same folder 
   as the Dev-C++ projects ("dev-c++" folder). 

4. Now open the "muscled.dev" file and press "Compile" button.
   This will create a "muscled.exe" file in the "Dev-C++" directory.
   Now you can just double-click it to run the server :).
