/* This file is Copyright 2000-2009 Meyer Sound Laboratories Inc.  See the included LICENSE.txt file for details. */  

#include <time.h>

#include "dataio/TCPSocketDataIO.h"
#include "iogateway/MessageIOGateway.h"
#include "reflector/StorageReflectConstants.h"
#include "regex/PathMatcher.h"
#include "util/NetworkUtilityFunctions.h"
#include "util/Hashtable.h"
#include "util/String.h"
#include "util/StringTokenizer.h"
#include "util/MiscUtilityFunctions.h"
#include "system/SetupSystem.h"

using namespace muscle;

#define VERSION_STRING "1.05"

// stolen from ShareNetClient.h
enum
{
   NET_CLIENT_CONNECTED_TO_SERVER = 0,
   NET_CLIENT_DISCONNECTED_FROM_SERVER,
   NET_CLIENT_NEW_CHAT_TEXT,
   NET_CLIENT_CONNECT_BACK_REQUEST,
   NET_CLIENT_CHECK_FILE_COUNT,
   NET_CLIENT_PING,
   NET_CLIENT_PONG,
   NET_CLIENT_SCAN_THREAD_REPORT
};                       

// ditto
enum
{
   ROOT_DEPTH = 0,         // root node
   HOST_NAME_DEPTH,
   SESSION_ID_DEPTH,
   BESHARE_HOME_DEPTH,     // used to separate our stuff from other (non-BeShare) data on the same server
   USER_NAME_DEPTH,        // user's handle node would be found here
   FILE_INFO_DEPTH         // user's shared file list is here
};         

static MessageRef GenerateChatMessage(const char * targetSessionID, const char * messageText)
{
   MessageRef chatMessage = GetMessageFromPool(NET_CLIENT_NEW_CHAT_TEXT);
   if (chatMessage())
   {
      String toString("/*/");  // send message to all hosts...
      toString += targetSessionID;
      toString += "/beshare";
      chatMessage()->AddString(PR_NAME_KEYS, toString.Cstr());
      chatMessage()->AddString("session", "blah");  // will be set by server
      chatMessage()->AddString("text", messageText);
      if (strcmp(targetSessionID, "*")) chatMessage()->AddBool("private", true);
   }
   return chatMessage;
}

static MessageRef GenerateServerSubscription(const char * subscriptionString, bool quietly)
{
   MessageRef queryMsg = GetMessageFromPool(PR_COMMAND_SETPARAMETERS);
   if (queryMsg())
   {
      queryMsg()->AddBool(subscriptionString, true);  // the true doesn't signify anything
      if (quietly) queryMsg()->AddBool(PR_NAME_SUBSCRIBE_QUIETLY, true);  // suppress initial-state response
   }
   return queryMsg;
}        

static MessageRef GenerateSetLocalUserName(const char * name)
{
   MessageRef uploadMsg = GetMessageFromPool(PR_COMMAND_SETDATA);
   MessageRef nameMessage = GetMessageFromPool();
   if ((uploadMsg())&&(nameMessage()))
   {
      nameMessage()->AddString("name", name);
      nameMessage()->AddInt32("port", 0);  // BeShare requires this, even though we don't use it
      nameMessage()->AddString("version_name", "MUSCLE demo chat client");
      nameMessage()->AddString("version_num", VERSION_STRING);
      uploadMsg()->AddMessage("beshare/name", nameMessage);
   }
   return uploadMsg;
}              

static MessageRef GenerateSetLocalUserStatus(const char * name)
{
   MessageRef uploadMsg = GetMessageFromPool(PR_COMMAND_SETDATA);
   MessageRef nameMessage = GetMessageFromPool();
   if ((uploadMsg())&&(nameMessage()))
   {
      nameMessage()->AddString("userstatus", name);
      uploadMsg()->AddMessage("beshare/userstatus", nameMessage);
   }
   return uploadMsg;
}              

static String GetUserName(Hashtable<String, String> & users, const String & sessionID)
{
   String ret;
   String * userName = users.Get(sessionID);
   return sessionID + "/" + (userName ? (*userName) : String("<unknown>"));
}

// Simple little text-based BeShare-compatible chat client.  Should work with any muscled server.
int main(int argc, char ** argv)
{
   CompleteSetupSystem css;

#ifdef SELECT_ON_FILE_DESCRIPTORS_NOT_AVAILABLE
   printf("Warning:  This program does not run very well on this OS, because the OS can not select() on stdin.  You'll need to press return a lot.\n");
#endif

   Message args;
   (void) ParseArgs(argc, argv, args);

   const char * hostName   = "beshare.tycomsystems.com";  (void) args.FindString("server", &hostName);
   const char * userName   = "clyde";                     (void) args.FindString("nick", &userName);
   const char * userStatus = "here";                      (void) args.FindString("status", &userStatus);
   const char * tempStr;
   uint16 port = 0; if (args.FindString("port", &tempStr) == B_NO_ERROR) port = (uint16) atoi(tempStr);
   if (port == 0) port = 2960;
      
   // Connect to the server
   ConstSocketRef s = Connect(hostName, port, "clyde", false);
   if (s() == NULL) return 10;

   // Do initial setup
   MessageIOGateway gw; gw.SetDataIO(DataIORef(new TCPSocketDataIO(s, false)));
   gw.AddOutgoingMessage(GenerateSetLocalUserName(userName));
   gw.AddOutgoingMessage(GenerateSetLocalUserStatus(userStatus));
   gw.AddOutgoingMessage(GenerateServerSubscription("SUBSCRIBE:beshare/*", false));
 
   // Our event loop
   char buf[1000] = "";
   fd_set readSet, writeSet;
   Hashtable<String, String> _users;
   QueueGatewayMessageReceiver inQueue;
   while(s())
   {
      FD_ZERO(&readSet);
      FD_ZERO(&writeSet);

      int fd = s.GetFileDescriptor();
      int maxfd = fd;
      FD_SET(fd, &readSet);
      struct timeval * timeout = NULL;
      struct timeval poll = {0, 0};

      if (gw.HasBytesToOutput()) FD_SET(fd, &writeSet);

      String text;
#ifdef SELECT_ON_FILE_DESCRIPTORS_NOT_AVAILABLE
      // BeOS can't select() on stdin (yet), so just make the user press enter or whatever
      fflush(stdout);
      if (fgets(buf, sizeof(buf), stdin) == NULL) buf[0] = '\0';
      char * ret = strchr(buf, '\n'); if (ret) *ret = '\0';
      text = buf;
      timeout = &poll;  // prohibit blocking in select()
#else
      if (STDIN_FILENO > maxfd) maxfd = STDIN_FILENO;
      FD_SET(STDIN_FILENO, &readSet);
#endif

      while(s()) 
      {
         if (select(maxfd+1, &readSet, &writeSet, NULL, timeout) < 0) 
         {
            LogTime(MUSCLE_LOG_CRITICALERROR, "select() failed!\n");
            s.Reset();
            break;
         }

         timeout = &poll;  // only block the first time (Linux) or not at all (BeOS)

#ifndef SELECT_ON_FILE_DESCRIPTORS_NOT_AVAILABLE
         if (FD_ISSET(STDIN_FILENO, &readSet)) 
         {
            if (fgets(buf, sizeof(buf), stdin) == NULL) buf[0] = '\0';
            char * ret = strchr(buf, '\n'); if (ret) *ret = '\0';
            text = buf;
         }
#endif

         text = text.Trim();
         StringTokenizer tok(text());
         const char * targetSessionID = "*";
         if (text.StartsWith("/msg "))
         {
            (void) tok();
            targetSessionID = tok();
            String sendText = String(tok.GetRemainderOfString()).Trim();
            if (sendText.HasChars()) gw.AddOutgoingMessage(GenerateChatMessage(targetSessionID, sendText()));
         }
         else if (text.StartsWith("/nick "))
         {
            (void) tok();
            String name = String(tok.GetRemainderOfString()).Trim();
            if (name.HasChars()) 
            {
               LogTime(MUSCLE_LOG_INFO, "Setting local user name to [%s]\n", name());
               gw.AddOutgoingMessage(GenerateSetLocalUserName(name()));
            }
         }
         else if (text.StartsWith("/status "))
         {
            (void) tok();
            String status = String(tok.GetRemainderOfString()).Trim();
            if (status.HasChars())
            {
               LogTime(MUSCLE_LOG_INFO, "Setting local user status to [%s]\n", status());
               gw.AddOutgoingMessage(GenerateSetLocalUserStatus(status()));
            }
         }
         else if (text.StartsWith("/help"))
         {
            LogTime(MUSCLE_LOG_INFO, "Available commands are:  /nick, /msg, /status, /help, and /quit\n");
         }
         else if (text.StartsWith("/quit")) s.Reset();
         else if (strlen(text()) > 0) gw.AddOutgoingMessage(GenerateChatMessage("*", text()));

         text.Clear();

         bool reading = FD_ISSET(fd, &readSet);
         bool writing = FD_ISSET(fd, &writeSet);
         bool writeError = ((writing)&&(gw.DoOutput() < 0));
         bool readError  = ((reading)&&(gw.DoInput(inQueue) < 0));
         if ((readError)||(writeError))
         {
            LogTime(MUSCLE_LOG_ERROR, "Connection closed, exiting.\n");
            s.Reset();
         }

         MessageRef msg;
         while(inQueue.RemoveHead(msg) == B_NO_ERROR)
         {
            switch(msg()->what)
            {
               case NET_CLIENT_PING:  // respond to other clients' pings
               {
                  String replyTo;
                  if (msg()->FindString("session", replyTo) == B_NO_ERROR)
                  {
                     msg()->what = NET_CLIENT_PONG;

                     String toString("/*/");
                     toString += replyTo;
                     toString += "/beshare";

                     msg()->RemoveName(PR_NAME_KEYS);
                     msg()->AddString(PR_NAME_KEYS, toString);

                     msg()->RemoveName("session");
                     msg()->AddString("session", "blah");  // server will set this correctly for us

                     msg()->RemoveName("version");
                     msg()->AddString("version", "MUSCLE demo chat client v" VERSION_STRING);

                     gw.AddOutgoingMessage(msg);
                  }
               }
               break;

               case NET_CLIENT_NEW_CHAT_TEXT:
               {
                  // Someone has sent a line of chat text to display
                  const char * text;
                  const char * session;
                  if ((msg()->FindString("text", &text) == B_NO_ERROR)&&(msg()->FindString("session", &session) == B_NO_ERROR)) 
                  {
                     if (strncmp(text, "/me ", 4) == 0) LogTime(MUSCLE_LOG_INFO, "<ACTION>: %s %s\n", GetUserName(_users, session)(), &text[4]); 
                                                   else LogTime(MUSCLE_LOG_INFO, "%s(%s): %s\n", msg()->HasName("private") ? "<PRIVATE>: ":"", GetUserName(_users, session)(), text);
                  }
               }
               break;     

               case PR_RESULT_DATAITEMS:
               {
                  // Look for sub-messages that indicate that nodes were removed from the tree
                  String nodepath;
                  for (int i=0; (msg()->FindString(PR_NAME_REMOVED_DATAITEMS, i, nodepath) == B_NO_ERROR); i++)
                  {
                     int pathDepth = GetPathDepth(nodepath.Cstr());
                     if (pathDepth >= USER_NAME_DEPTH)
                     {
                        String sessionID = GetPathClause(SESSION_ID_DEPTH, nodepath.Cstr());
                        sessionID = sessionID.Substring(0, sessionID.IndexOf('/'));

                        switch(GetPathDepth(nodepath.Cstr()))
                        {
                           case USER_NAME_DEPTH:
                           if (strncmp(GetPathClause(USER_NAME_DEPTH, nodepath.Cstr()), "name", 4) == 0) 
                           {
                              String userName = GetUserName(_users, sessionID);
                              if (_users.Remove(sessionID) == B_NO_ERROR) LogTime(MUSCLE_LOG_INFO, "User [%s] has disconnected.\n", userName());
                           }
                           break;
                        }
                     }
                  }

                  // Look for sub-messages that indicate that nodes were added to the tree
                  for (MessageFieldNameIterator iter = msg()->GetFieldNameIterator(B_MESSAGE_TYPE); iter.HasData(); iter++)
                  {
                     const String & np = iter.GetFieldName();
                     int pathDepth = GetPathDepth(np());
                     if (pathDepth == USER_NAME_DEPTH)
                     {
                        MessageRef tempRef;
                        if (msg()->FindMessage(np, tempRef) == B_NO_ERROR)
                        {
                           const Message * pmsg = tempRef();
                           String sessionID = GetPathClause(SESSION_ID_DEPTH, np());
                           sessionID = sessionID.Substring(0, sessionID.IndexOf('/'));
                           switch(pathDepth)
                           {
                              case USER_NAME_DEPTH:
                              {
                                 String hostName = GetPathClause(HOST_NAME_DEPTH, np());
                                 hostName = hostName.Substring(0, hostName.IndexOf('/'));

                                 const char * nodeName = GetPathClause(USER_NAME_DEPTH, np());
                                 if (strncmp(nodeName, "name", 4) == 0)
                                 {
                                    const char * name;
                                    if (pmsg->FindString("name", &name) == B_NO_ERROR)
                                    {
                                       if (_users.ContainsKey(sessionID) == false) LogTime(MUSCLE_LOG_INFO, "User #%s has connected\n", sessionID());
                                       _users.Put(sessionID, name);
                                       LogTime(MUSCLE_LOG_INFO, "User #%s is now known as %s\n", sessionID(), name);
                                    }
                                 }
                                 else if (strncmp(nodeName, "userstatus", 9) == 0)
                                 {
                                    const char * status;
                                    if (pmsg->FindString("userstatus", &status) == B_NO_ERROR) LogTime(MUSCLE_LOG_INFO, "%s is now [%s]\n", GetUserName(_users, sessionID)(), status);
                                 }
                              }
                              break;
                           }
                        }
                     }
                  }
               }
            }
         }

         if ((reading == false)&&(writing == false)) break;

         FD_ZERO(&readSet);
         FD_ZERO(&writeSet);
         FD_SET(fd, &readSet);
         if (gw.HasBytesToOutput()) FD_SET(fd, &writeSet);
      }
   } 

   if (gw.HasBytesToOutput())
   {
      LogTime(MUSCLE_LOG_INFO, "Waiting for all pending messages to be sent...\n");
      while((gw.HasBytesToOutput())&&(gw.DoOutput() >= 0)) {Log(MUSCLE_LOG_INFO, "."); fflush(stdout);}
   }
   LogTime(MUSCLE_LOG_INFO, "Bye!\n");

   return 0;
}
