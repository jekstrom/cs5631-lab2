/* This file is Copyright 2000-2009 Meyer Sound Laboratories Inc.  See the included LICENSE.txt file for details. */  

#include <stdio.h>

#include "dataio/StdinDataIO.h"
#include "dataio/TCPSocketDataIO.h"
#include "dataio/RS232DataIO.h"
#include "system/SetupSystem.h"
#include "util/NetworkUtilityFunctions.h"
#include "util/MiscUtilityFunctions.h"

using namespace muscle;

static const int DEFAULT_PORT = 5274;  // What CueStation 2.5 connects to by deafult

static status_t ReadIncomingData(const char * desc, DataIO & readIO, fd_set & readSet, Queue<ByteBufferRef> & outQ)
{
   if (FD_ISSET(readIO.GetReadSelectSocket().GetFileDescriptor(), &readSet))
   {
      uint8 buf[4096];
      int32 ret = readIO.Read(buf, sizeof(buf));
      if (ret > 0) 
      {
         LogTime(MUSCLE_LOG_TRACE, "Read "INT32_FORMAT_SPEC" bytes from %s:\n", ret, desc);
         LogHexBytes(MUSCLE_LOG_TRACE, buf, ret);
     
         ByteBufferRef toNetworkBuf = GetByteBufferFromPool(ret, buf);
         if (toNetworkBuf()) (void) outQ.AddTail(toNetworkBuf); 
      }
      else if (ret < 0) {LogTime(MUSCLE_LOG_ERROR, "Error, readIO.Read() returned %i\n", ret); return B_ERROR;}
   }
   return B_NO_ERROR;
}

static status_t WriteOutgoingData(const char * desc, DataIO & writeIO, fd_set & writeSet, Queue<ByteBufferRef> & outQ, uint32 & writeIdx)
{
   if (FD_ISSET(writeIO.GetWriteSelectSocket().GetFileDescriptor(), &writeSet))
   {
      while(outQ.HasItems())
      {
         ByteBufferRef & firstBuf = outQ.Head();
         uint32 bufSize = firstBuf()->GetNumBytes();
         if (writeIdx >= bufSize) 
         {
            outQ.RemoveHead();
            writeIdx = 0;
         }
         else
         {
            int32 ret = writeIO.Write(firstBuf()->GetBuffer()+writeIdx, firstBuf()->GetNumBytes()-writeIdx);
            if (ret > 0)
            {
               writeIO.FlushOutput();
               LogTime(MUSCLE_LOG_TRACE, "Wrote "INT32_FORMAT_SPEC" bytes to %s:\n", ret, desc);
               LogHexBytes(MUSCLE_LOG_TRACE, firstBuf()->GetBuffer()+writeIdx, ret);
               writeIdx += ret;
            }
            else if (ret < 0) {LogTime(MUSCLE_LOG_ERROR, "Error, writeIO.Write() returned %i\n", ret); return B_ERROR;}
         }
      }
   }
   return B_NO_ERROR;
}

static status_t DoSession(DataIO & networkIO, DataIO & serialIO)
{
   Queue<ByteBufferRef> outgoingSerialData;
   Queue<ByteBufferRef> outgoingNetworkData;
   uint32 serialIndex = 0, networkIndex = 0;

   while(true)
   {
      int networkReadFD  = networkIO.GetReadSelectSocket().GetFileDescriptor();
      int serialReadFD   = serialIO.GetReadSelectSocket().GetFileDescriptor();
      int networkWriteFD = networkIO.GetWriteSelectSocket().GetFileDescriptor();
      int serialWriteFD  = serialIO.GetWriteSelectSocket().GetFileDescriptor();

      fd_set readSet; FD_ZERO(&readSet);  
      FD_SET(networkReadFD, &readSet);  
      FD_SET(serialReadFD,  &readSet);

      fd_set writeSet; FD_ZERO(&writeSet); 
      if (outgoingNetworkData.HasItems()) FD_SET(networkWriteFD,&writeSet); 
      if (outgoingSerialData.HasItems())  FD_SET(serialWriteFD, &writeSet); 

      if (select(muscleMax(networkReadFD, serialReadFD, networkWriteFD, serialWriteFD)+1, &readSet, &writeSet, NULL, NULL) >= 0)
      {
         if (ReadIncomingData("network",  networkIO, readSet,  outgoingSerialData)                != B_NO_ERROR) return B_NO_ERROR;  // tells main() to wait for the next TCP connection
         if (ReadIncomingData("serial",   serialIO,  readSet,  outgoingNetworkData)               != B_NO_ERROR) return B_ERROR;     // tells main() to exit
         if (WriteOutgoingData("network", networkIO, writeSet, outgoingNetworkData, networkIndex) != B_NO_ERROR) return B_NO_ERROR;  // tells main() to wait for the next TCP connection
         if (WriteOutgoingData("serial",  serialIO,  writeSet, outgoingSerialData,  serialIndex)  != B_NO_ERROR) return B_ERROR;     // tells main() to exit
      }
      else 
      {
         LogTime(MUSCLE_LOG_CRITICALERROR, "Error, select() failed!\n");
         return B_ERROR;
      }
   }
}

static void LogUsage()
{
   Log(MUSCLE_LOG_INFO, "Usage:  serialproxy serial=<devname>:<baud> [port=5274] (send/receive via a serial device, e.g. /dev/ttyS0)\n");
}

// This program acts as a proxy to forward serial data to a TCP stream (and back)
int main(int argc, char ** argv) 
{
   CompleteSetupSystem css;

   Message args; (void) ParseArgs(argc, argv, args);
   (void) HandleStandardDaemonArgs(args);

   if (args.HasName("help"))
   {
      LogUsage();
      return 0;
   }

   uint16 port = 0;
   {
      const String * ps = args.GetStringPointer("port");
      if (ps) port = atoi(ps->Cstr());
   }
   if (port == 0) port = DEFAULT_PORT;
   
   String arg;
   if (args.FindString("serial", arg) == B_NO_ERROR)
   {
      const char * colon = strchr(arg(), ':');
      uint32 baudRate = colon ? atoi(colon+1) : 0; if (baudRate == 0) baudRate = 38400;
      String devName = arg.Substring(0, ":");
      Queue<String> devs;
      if (RS232DataIO::GetAvailableSerialPortNames(devs) == B_NO_ERROR)
      {
         String serName;
         for (int32 i=devs.GetNumItems()-1; i>=0; i--)
         {
            if (devs[i] == devName) 
            {
               serName = devs[i];
               break;
            }
         }
         if (serName.HasChars())
         {
            RS232DataIO serialIO(devName(), baudRate, false);
            if (serialIO.IsPortAvailable())
            {
               LogTime(MUSCLE_LOG_INFO, "Using serial port %s (baud rate "UINT32_FORMAT_SPEC")\n", serName(), baudRate);

               ConstSocketRef serverSock = CreateAcceptingSocket(port, 1);
               if (serverSock())
               {
                  // Now we just wait here until a TCP connection comes along on our port...
                  bool keepGoing = true;
                  while(keepGoing)
                  {
                     LogTime(MUSCLE_LOG_INFO, "Awaiting incoming TCP connection on port %u...\n", port);
                     ConstSocketRef tcpSock = Accept(serverSock);
                     if (tcpSock())
                     {
                        LogTime(MUSCLE_LOG_INFO, "Beginning serial proxy session!\n");
                        TCPSocketDataIO networkIO(tcpSock, false);
                        keepGoing = (DoSession(networkIO, serialIO) == B_NO_ERROR);
                        LogTime(MUSCLE_LOG_INFO, "Serial proxy session ended%s!\n", keepGoing?", awaiting new connection":", aborting!");
                     }
                  }
               }
               else LogTime(MUSCLE_LOG_CRITICALERROR, "Unable to listen on TCP port %u\n", port);
            }
            else LogTime(MUSCLE_LOG_CRITICALERROR, "Unable to open serial device %s (baud rate "UINT32_FORMAT_SPEC").\n", serName(), baudRate);
         }
         else 
         {
            LogTime(MUSCLE_LOG_CRITICALERROR, "Serial device %s not found.\n", devName());
            LogTime(MUSCLE_LOG_CRITICALERROR, "Available serial devices are:\n");
            for (uint32 i=0; i<devs.GetNumItems(); i++) LogTime(MUSCLE_LOG_CRITICALERROR, "   %s\n", devs[i]());
         }
      }
      else LogTime(MUSCLE_LOG_CRITICALERROR, "Could not get list of serial device names!\n");
   }
   else LogUsage();

   LogTime(MUSCLE_LOG_INFO, "serialproxy exiting!\n");
   return 0;
}
