This is a basic BeShare client. It demonstrates more complex comms between the muscle server and multiple MUSCLE clients. 

Use: Run the client. Change the user and server text if desired - at the moment it is set to the primary BeShare server. You can use a local server if desired, if so 127.0.0.1 or LAN IP address should be used. To compile a server for use - see other documentation.

Typing text in the edit box on client one and then pressing the return key or the "send" button will send the text to all other clients connected to the BeShare server.

CAUTION: "/prv" is currently brokey. It will broadcase the private message to all clients.. but not so that you would see it. Not what you want at all!!!

That's about it for now! Enjoy!!!!