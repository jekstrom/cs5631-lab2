#/bin/sh
echo "Generating doxygen documentation.  "
echo "You will need to have doxygen installed in"
echo "order for this script to work."
echo ""
doxygen muscle.dox
echo "Done!"
